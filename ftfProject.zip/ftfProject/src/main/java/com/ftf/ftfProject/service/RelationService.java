package com.ftf.ftfProject.service;

import com.ftf.ftfProject.entity.Relation;

import java.util.List;

public interface RelationService {

    List<Relation> getAllRelation();
}
