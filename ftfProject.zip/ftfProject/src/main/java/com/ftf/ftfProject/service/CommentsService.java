package com.ftf.ftfProject.service;

import com.ftf.ftfProject.entity.Comments;

import java.util.List;

public interface CommentsService {

    List<Comments> getAllComments();
}
